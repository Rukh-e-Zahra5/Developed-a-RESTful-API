from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from database import db

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'supersecretkey'  # Change this in production

jwt = JWTManager(app)

import models
from models import User, Item  # Import models
db.init_app(app)

# Initialize database
with app.app_context():
    db.create_all()
    print("DB Created")

# Home route
@app.route("/", methods=["GET"])
def home():
    return jsonify({'message': 'Welcome to the API'})

# Register route
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data['username']
    password = data['password']

    if User.query.filter_by(username=username).first():
        return jsonify({"message": "User already exists"}), 409

    new_user = User(username=username, password=password)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({"message": "User created successfully"}), 201

# Login route
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data['username']
    password = data['password']

    user = User.query.filter_by(username=username).first()

    if user and user.check_password(password):
        token = create_access_token(identity=user.id)
        return jsonify({"token": token}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

# Protected route: Get items (JWT required)
@app.route('/items', methods=['GET'])
@jwt_required()
def get_items():
    items = Item.query.all()
    return jsonify([item.to_dict() for item in items]), 200

# Protected route: Create item (JWT required)
@app.route('/items', methods=['POST'])
@jwt_required()
def create_item():
    data = request.get_json()
    new_item = Item(name=data['name'], description=data['description'])
    db.session.add(new_item)
    db.session.commit()
    return jsonify(new_item.to_dict()), 201

# Protected route: Get specific item (JWT required)
@app.route('/items/<int:item_id>', methods=['GET'])
@jwt_required()
def get_item(item_id):
    try:
        item = Item.query.get_or_404(item_id)
        return jsonify(item.to_dict()), 200
    except:
        return jsonify({'message': 'Item not found'}), 404

# Protected route to update an item
@app.route('/items/<int:item_id>', methods=['PUT'])
@jwt_required()  # JWT authentication required
def update_item(item_id):
    item = Item.query.get_or_404(item_id)
    data = request.get_json()
    item.name = data['name']
    item.description = data['description']
    db.session.commit()
    return jsonify(item.to_dict()), 200


# Protected route to delete an item
@app.route('/items/<int:item_id>', methods=['DELETE'])
@jwt_required()  # JWT authentication required
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'message': 'Item deleted successfully'}), 200